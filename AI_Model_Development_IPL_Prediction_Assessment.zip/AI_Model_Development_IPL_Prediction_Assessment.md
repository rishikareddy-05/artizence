
# AI Model Development for IPL Prediction

## 1. ML Model and LLM Reasoning Integration

### 1.1. Ensemble Model (ml_models/ensemble.py)
```python
import numpy as np
import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.base import BaseEstimator, ClassifierMixin

class EnsembleModel(BaseEstimator, ClassifierMixin):
    def __init__(self):
        self.xgb_model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
        self.meta_model = LogisticRegression()
    
    def fit(self, X, y):
        self.xgb_model.fit(X, y)
        xgb_prob = self.xgb_model.predict_proba(X)
        self.meta_model.fit(xgb_prob, y)
        return self

    def predict(self, X):
        xgb_prob = self.xgb_model.predict_proba(X)
        return self.meta_model.predict(xgb_prob)
    
    def predict_proba(self, X):
        xgb_prob = self.xgb_model.predict_proba(X)
        return self.meta_model.predict_proba(xgb_prob)
```

### 1.2. LLM Reasoning Integration (llm_integration/ollama_client.py)
```python
import requests

def get_llm_reasoning(match_info, prediction):
    prompt = (
        f"Match Details: {match_info}\n"
        f"Prediction: {prediction}\n"
        "Explain in detail why this outcome is likely..."
    )
    
    try:
        response = requests.post("http://localhost:11434/predict", json={"prompt": prompt})
        if response.status_code == 200:
            return response.json().get("reasoning", "LLM did not return reasoning.")
        else:
            return "LLM error: " + response.text
    except Exception as e:
        return f"LLM integration exception: {str(e)}"
```

## 2. API Implementations

### 2.1 Django-Based API (django_app/ipl_app/views.py)
```python
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import numpy as np

from ml_models.ensemble import EnsembleModel
from llm_integration.ollama_client import get_llm_reasoning

np.random.seed(42)
X_dummy = np.random.rand(100, 10)
y_dummy = np.random.randint(0, 2, 100)
ensemble_model = EnsembleModel().fit(X_dummy, y_dummy)

class PredictMatchView(APIView):
    def post(self, request):
        data = request.data
        features = data.get("features")
        if features is None:
            return Response({"error": "Features not provided"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            features = np.array(features).reshape(1, -1)
            prediction = int(ensemble_model.predict(features)[0])
            match_info = data.get("match_info", "Standard match conditions")
            reasoning = get_llm_reasoning(match_info, prediction)
            return Response({"prediction": prediction, "reasoning": reasoning})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
```

### 2.2 FastAPI-Based API (fastapi_app/main.py)
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np

from ml_models.ensemble import EnsembleModel
from llm_integration.ollama_client import get_llm_reasoning

app = FastAPI()

np.random.seed(42)
X_dummy = np.random.rand(100, 10)
y_dummy = np.random.randint(0, 2, 100)
ensemble_model = EnsembleModel().fit(X_dummy, y_dummy)

class PredictionRequest(BaseModel):
    features: list
    match_info: str = "Standard match conditions"

@app.post("/predict/")
async def predict_match(data: PredictionRequest):
    try:
        features = np.array(data.features).reshape(1, -1)
        prediction = int(ensemble_model.predict(features)[0])
        reasoning = get_llm_reasoning(data.match_info, prediction)
        return {"prediction": prediction, "reasoning": reasoning}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

## 3. Dockerfile (docker/Dockerfile)
```dockerfile
FROM python:3.9-slim

ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

WORKDIR /app

COPY requirements.txt /app/
RUN pip install --upgrade pip
RUN pip install -r requirements.txt

COPY . /app/

EXPOSE 8000 8001

CMD ["python", "django_app/manage.py", "runserver", "0.0.0.0:8000"]
```

## 4. Suggested Folder Structure
```
ipl_prediction/
├── backend/
│   ├── django_app/
│   │   ├── ipl_app/
│   ├── fastapi_app/
├── llm_integration/
├── ml_models/
├── data_pipeline/
├── evaluation/
├── docker/
├── requirements.txt
└── README.md
```

## 5. Next Steps
- Replace dummy data with real IPL datasets.
- Add time-series models and player score regressors.
- Tune prompts for LLM reasoning.
- Improve retraining and monitoring pipelines.
